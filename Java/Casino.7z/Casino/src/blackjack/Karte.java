package blackjack;

public class Karte {
	int kartennummer;
	int zuordnung;
	int wert;
}